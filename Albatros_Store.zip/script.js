
function exploreProducts() {
    alert('سيتم استكشاف المنتجات قريبًا!');
}
